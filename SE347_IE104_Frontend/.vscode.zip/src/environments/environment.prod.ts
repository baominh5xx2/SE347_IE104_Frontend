export const environment = {
  production: true,
  apiUrl: '/api/v1'
};

